import asyncio
import contextlib
from unittest import mock

import synapse.exc as s_exc
import synapse.common as s_common

import synapse.lib.auth as s_auth
import synapse.lib.cell as s_cell
import synapse.lib.nexus as s_nexus

import synapse.tools.service.backup as s_backup

import synapse.tests.utils as s_t_utils

class SampleNexus(s_cell.Cell):

    async def doathing(self, eventdict):
        return await self._push('thing:doathing', eventdict, 'foo')

    @s_nexus.Pusher.onPush('thing:doathing')
    async def _doathinghandler(self, eventdict, anotherparm):
        eventdict['happened'] = self.iden
        return anotherparm

    async def _push(self, event, *args, **kwargs):
        eventdict = args[0]
        eventdict['specialpush'] += 1
        return await s_nexus.Pusher._push(self, event, *args, **kwargs)

    async def doathing2(self, eventdict):
        return await self._push('thing:doathing2', eventdict, 'foo')

    @s_nexus.Pusher.onPush('thing:doathing2', passitem=True)
    async def _doathing2handler(self, eventdict, anotherparm, nexsitem=None):
        nexsoff, nexsmesg = nexsitem
        eventdict['gotindex'] = nexsoff
        return anotherparm

    @s_nexus.Pusher.onPushAuto('auto2')
    async def doathingauto(self, eventdict, anotherparm):
        eventdict['autohappened'] = self.iden
        return anotherparm

    @s_nexus.Pusher.onPushAuto('auto1')
    async def doathingauto2(self, eventdict, anotherparm):
        '''doc'''
        eventdict['autohappened2'] = self.iden
        return anotherparm

    @s_nexus.Pusher.onPushAuto('auto3')
    async def doathingauto3(self, eventdict):
        raise s_exc.SynErr(mesg='Test error')

class SampleMixin(metaclass=s_nexus.RegMethType):
    @s_nexus.Pusher.onPushAuto('mixinthing')
    async def mixinthing(self, eventdict):
        eventdict['autohappened3'] = self.iden
        return 42

class SampleNexus2(SampleNexus, SampleMixin):
    async def doathing(self, eventdict):
        return await self._push('thing:doathing', eventdict, 'bar')

class NexusTest(s_t_utils.SynTest):

    async def test_nexus_base(self):

        with self.getTestDir() as dirn:
            dir1 = s_common.genpath(dirn, 'nexus1')
            dir2 = s_common.genpath(dirn, 'nexus2')
            guid1 = s_common.guid('nexus1')
            guid2 = s_common.guid('nexus2')

            conf1 = {'cell:guid': guid1, 'nexslog:en': True}
            async with await SampleNexus.anit(conf=conf1, dirn=dir1) as nexus1:
                nexsroot = nexus1.nexsroot

                eventdict = {'specialpush': 0}
                self.eq('foo', await nexus1.doathing(eventdict))
                self.eq(guid1, eventdict.get('happened'))

                self.eq('foo', await nexus1.doathingauto(eventdict, 'foo'))
                self.eq(guid1, eventdict.get('autohappened'))

                self.eq('foo', await nexus1.doathingauto2(eventdict, 'foo'))
                self.eq(guid1, eventdict.get('autohappened2'))

                self.eq('doc', nexus1.doathingauto2.__doc__)

                self.eq(3, await nexsroot.index())

                conf2 = {'cell:guid': guid2, 'nexslog:en': True}
                async with await SampleNexus2.anit(conf=conf2, dirn=dir2, parent=nexus1) as nexus2:

                    eventdict = {'specialpush': 0}
                    # Tricky inheriting handler funcs themselves
                    self.eq('foo', await nexus1.doathing(eventdict))
                    self.eq('bar', await nexus2.doathing(eventdict))
                    self.eq(guid2, eventdict.get('happened'))

                    # Check offset passing
                    self.eq('foo', await nexus2.doathing2(eventdict))
                    self.eq(5, eventdict.get('gotindex'))

                    # Check raising an exception
                    with self.raises(s_exc.SynErr) as cm:
                        await nexus2.doathingauto3(eventdict)
                    self.eq(cm.exception.get('mesg'), 'Test error')

                    with self.getLoggerStream('synapse.lib.nexus') as stream:
                        await nexsroot.recover()

                    stream.seek(0)
                    self.isin('while replaying log', stream.read())

                    nexsindx = nexus1.nexsroot.nexslog.index()

                    async def listen():
                        async for item in nexus1.getNexusChanges(nexsindx, wait=True):
                            break
                        return item

                    task = nexus1.schedCoro(listen())
                    self.eq('foo', await nexus1.doathing(eventdict))
                    offs, item = await asyncio.wait_for(task, timeout=12)
                    self.eq(offs, nexsindx)
                    self.eq(item[1], 'thing:doathing')

    async def test_nexus_fini(self):

        conf = {'nexslog:en': True}
        async with self.getTestCell(conf=conf) as cell:
            await cell.sync()

        # Cannot issue new items to the nexusroot after fini
        with self.raises(s_exc.IsFini) as cm:
            await cell.sync()
        self.isin('Nexus has been shutdown, cannot propose', cm.exception.get('mesg'))
        self.false(cell.nexslock.locked())

        # Cannot iterate over the log after fini
        with self.raises(s_exc.IsFini) as cm:
            async for item in cell.getNexusChanges(0, wait=False):
                pass
        self.isin('Nexus has been shutdown, cannot iterate changes.', cm.exception.get('mesg'))

        # Patch to delay the execution _eat so we can fini the service
        # AFTER the lock has been obtained and BEFORE the apply task
        # has started to execute.

        async with self.getTestCell(conf=conf) as cell:
            await cell.sync()

            orig_eat = cell.nexsroot._eat
            async def func(item, indx=None):
                await cell.fini()
                await orig_eat(item, indx=indx)

            with mock.patch('synapse.lib.nexus.NexsRoot._eat', func):
                with self.assertRaises(s_exc.IsFini) as cm:
                    await cell.sync()
                self.isin('Nexus has been shutdown, cannot apply', cm.exception.get('mesg'))
            self.true(cell.isfini)
            self.false(cell.nexslock.locked())

    async def test_nexus_modroot(self):

        async with self.getTestCell() as cell:
            await cell.sync()
            async with cell.nexslock:
                await cell.modNexsRoot(cell._ctorNexsRoot)
            await cell.sync()

    async def test_nexus_mixin(self):
        with self.getTestDir() as dirn:
            dir1 = s_common.genpath(dirn, 'nexus1')
            dir2 = s_common.genpath(dirn, 'nexus2')
            guid1 = s_common.guid('nexus1')
            guid2 = s_common.guid('nexus2')

            conf1 = {'cell:guid': guid1, 'nexslog:en': True}
            async with await SampleNexus.anit(conf=conf1, dirn=dir1) as nexus1:
                conf1 = {'cell:guid': guid2, 'nexslog:en': True}
                async with await SampleNexus2.anit(conf=conf1, dirn=dir2, parent=nexus1) as nexus2:
                    eventdict = {'specialpush': 0}
                    self.eq('bar', await nexus2.doathing(eventdict))
                    self.eq(42, await nexus2.mixinthing(eventdict))

    async def test_nexus_no_logging(self):
        '''
        Pushers/NexsRoot works with donexslog=False
        '''
        with self.getTestDir() as dirn:
            dir1 = s_common.genpath(dirn, 'nexus1')
            dir2 = s_common.genpath(dirn, 'nexus2')
            guid1 = s_common.guid('nexus1')
            guid2 = s_common.guid('nexus2')

            conf1 = {'cell:guid': guid1, 'nexslog:en': False}
            async with await SampleNexus.anit(conf=conf1, dirn=dirn) as nexus1:
                nexsroot = nexus1.nexsroot

                eventdict = {'specialpush': 0}
                self.eq('foo', await nexus1.doathing(eventdict))
                self.eq('foo', await nexus1.doathing2(eventdict))
                self.eq(guid1, eventdict.get('happened'))
                self.eq(1, eventdict.get('gotindex'))

                self.eq(2, await nexsroot.index())

                conf2 = {'cell:guid': guid2, 'nexslog:en': False}
                async with await SampleNexus2.anit(conf=conf2, dirn=dir2, parent=nexus1) as nexus2:
                    eventdict = {'specialpush': 0}
                    self.eq('bar', await nexus2.doathing(eventdict))
                    self.eq('foo', await nexus2.doathing2(eventdict))
                    self.eq(guid2, eventdict.get('happened'))
                    self.eq(3, eventdict.get('gotindex'))

    async def test_nexus_migration(self):
        with self.getRegrDir('cortexes', 'reindex-byarray3') as regrdirn:
            slabsize00 = s_common.getDirSize(regrdirn)
            async with self.getTestCore(dirn=regrdirn) as core00:
                await self.waitForActiveMigration(core00)

                slabsize01 = s_common.getDirSize(regrdirn)
                # Ensure that realsize hasn't grown wildly. That would be indicative
                # of a sparse file copy and not a directory move.
                self.lt(slabsize01[0], 4 * slabsize00[0])

                nexsindx = await core00.getNexsIndx()
                layrindx = max([await layr.getEditIndx() for layr in core00.layers.values()])
                self.ge(nexsindx, layrindx)

                retn = await core00.nexsroot.nexslog.get(0)
                self.nn(retn)
                self.eq([0], core00.nexsroot.nexslog._ranges)
                items = await s_t_utils.alist(core00.nexsroot.nexslog.iter(0))
                self.ge(len(items), 62)

    async def test_nexus_setindex(self):

        async with self.getRegrCore('migrated-nexuslog') as core00:

            nexsindx = await core00.getNexsIndx()
            layrindx = max([await layr.getEditIndx() for layr in core00.layers.values()])
            self.ge(nexsindx, layrindx)

            # Make sure a mirror gets updated to the correct index
            url = core00.getLocalUrl()
            core01conf = {'mirror': url}

            async with self.getRegrCore('migrated-nexuslog', conf=core01conf) as core01:

                await core01.sync()

                layrindx = max([await layr.getEditIndx() for layr in core01.layers.values()])
                self.ge(nexsindx, layrindx)

            # Can only move index forward
            self.false(await core00.setNexsIndx(0))

        # Test with nexuslog disabled
        nologconf = {'nexslog:en': False}
        async with self.getRegrCore('migrated-nexuslog', conf=nologconf) as core:

            nexsindx = await core.getNexsIndx()
            layrindx = max([await layr.getEditIndx() for layr in core.layers.values()])
            self.ge(nexsindx, layrindx)

    async def test_nexus_safety(self):

        evnt = asyncio.Event()
        orig = s_auth.Auth.reqUser
        async def slowReq(self, iden):
            await evnt.wait()
            return await orig(self, iden)

        with self.getTestDir() as dirn:
            async with self.getTestCore(dirn=dirn) as core:

                with mock.patch('synapse.lib.auth.Auth.reqUser', slowReq):

                    vcnt = len(core.views)
                    deflayr = (await core.getLayerDef()).get('iden')

                    strt = await core.nexsroot.index()

                    vdef = {'layers': (deflayr,), 'name': 'nextview'}
                    core.schedCoro(core.addView(vdef))

                    for x in range(10):
                        vdef = {'layers': (deflayr,), 'name': f'someview{x}'}
                        core.schedCoro(core.addView(vdef))

                    await asyncio.sleep(0.1)

            async with self.getTestCore(dirn=dirn) as core:

                viewadds = 0
                async for item in core.nexsroot.nexslog.iter(strt):
                    if item[1][1] == 'view:add':
                        viewadds += 1

                self.eq(1, viewadds)
                self.len(vcnt + viewadds, core.views)
                self.len(1, [v for v in core.views.values() if (await v.pack())['name'] == 'nextview'])

                vcnt = len(core.views)
                strt = await core.nexsroot.index()

                with mock.patch('synapse.lib.auth.Auth.reqUser', slowReq):

                    # Two of these should time out before acquiring nexslock and fail to happen
                    for x in range(3):
                        vdef = {'layers': (deflayr,), 'name': f'someview{x}'}
                        with self.raises(TimeoutError):
                            await s_common.wait_for(core.addView(vdef), 0.1)

                    # This will get the lock and succeed
                    vdef = {'layers': (deflayr,), 'name': 'waitview'}
                    core.schedCoro(core.addView(vdef))
                    evnt.set()

                await core.sync()

                viewadds = []
                async for item in core.nexsroot.nexslog.iter(strt):
                    if item[1][1] == 'view:add':
                        viewadds.append(item[1][2][0]['name'])

                self.eq(viewadds, ['someview0', 'waitview'])
                self.len(vcnt + len(viewadds), core.views)

            async with self.getTestCore(dirn=dirn) as core:
                self.len(vcnt + len(viewadds), core.views)

    async def test_mirror_version(self):

        with self.getTestDir() as dirn:

            s_common.yamlsave({'nexslog:en': True}, dirn, 'cell.yaml')
            async with await s_cell.Cell.anit(dirn=dirn) as cell00:

                getCellInfo = cell00.getCellInfo
                async def getCrazyVersion():
                    info = await getCellInfo()
                    info['cell']['version'] = (9999, 0, 0)
                    return info

                await cell00.runBackup(name='cell01')

                path = s_common.genpath(dirn, 'backups', 'cell01')

                conf = s_common.yamlload(path, 'cell.yaml')
                conf['mirror'] = f'cell://{dirn}'
                s_common.yamlsave(conf, path, 'cell.yaml')

                evnt = asyncio.Event()
                cell00.getCellInfo = getCrazyVersion

                async with await s_cell.Cell.anit(dirn=path) as cell01:
                    addWriteHold = cell01.nexsroot.addWriteHold
                    def wrapAddWriteHold(reason):
                        retn = addWriteHold(reason)
                        evnt.set()
                        return retn

                    cell01.nexsroot.addWriteHold = wrapAddWriteHold
                    await asyncio.wait_for(evnt.wait(), timeout=3)

                    with self.raises(s_exc.IsReadOnly):
                        await cell01.sync()
                    self.isin(s_nexus.leaderversion, cell01.nexsroot.writeholds)

                cell00.getCellInfo = getCellInfo

                # test case where a mirror which is updated first may push events
                # the leader does not yet have handlers for
                async with await s_cell.Cell.anit(dirn=path) as cell01:
                    cell01.nexsiden = 'newp'
                    with self.raises(s_exc.NoSuchIden) as cm:
                        await cell01.sync()
                    self.eq(cm.exception.get('mesg'), "No Nexus Pusher with iden newp event='sync' args=() kwargs={}")

                    self.none(await cell00.nexsroot.nexslog.last())
                    self.none(await cell01.nexsroot.nexslog.last())

                    cell01.nexsiden = cell00.nexsiden
                    await cell01.sync()

                    self.eq(0, (await cell00.nexsroot.nexslog.last())[0])
                    self.eq(0, (await cell01.nexsroot.nexslog.last())[0])

                    with self.raises(s_exc.NoSuchName) as cm:
                        await cell01._push('newp')
                    self.eq(cm.exception.get('mesg'), 'No event handler for event newp args=() kwargs={}')

                    self.eq(0, (await cell00.nexsroot.nexslog.last())[0])
                    self.eq(0, (await cell01.nexsroot.nexslog.last())[0])

    async def test_mirror_nexus_loop_failure(self):
        with self.getTestDir() as dirn:

            s_common.yamlsave({'nexslog:en': True}, dirn, 'cell.yaml')
            async with await s_cell.Cell.anit(dirn=dirn) as cell00:

                await cell00.runBackup(name='cell01')

                path = s_common.genpath(dirn, 'backups', 'cell01')

                conf = s_common.yamlload(path, 'cell.yaml')
                conf['mirror'] = f'cell://{dirn}'
                s_common.yamlsave(conf, path, 'cell.yaml')

                seen = False
                restarted = False
                orig = s_nexus.NexsRoot.delWriteHold

                # Patch NexsRoot.delWriteHold so we can cause an exception in
                # the setup part of the nexus loop (NexsRoot.runMirrorLoop). The
                # exception should only happen one time so we can check that the
                # proxy and the nexus loop were both restarted
                async def delWriteHold(self, reason):
                    nonlocal seen
                    nonlocal restarted
                    if not seen and reason == s_nexus.leaderversion:
                        seen = True
                        raise Exception('Knock over the nexus setup.')

                    restarted = True
                    return await orig(self, reason)

                with mock.patch('synapse.lib.nexus.NexsRoot.delWriteHold', delWriteHold):
                    with self.getLoggerStream('synapse.lib.nexus') as stream:
                        async with await s_cell.Cell.anit(dirn=path) as cell01:
                            await cell01.sync()

                    stream.seek(0)
                    data = stream.read()
                    mesg = 'Unknown error during mirror loop startup: Knock over the nexus setup.'
                    self.isin(mesg, data)

                self.true(restarted)

    async def test_pusher_race(self):

        evnt = asyncio.Event()

        async with self.getTestCore() as core:
            forkiden = await core.callStorm('return($lib.view.get().fork().iden)')

            # Remove the nexus handler for the fork's write layer to simulate a view delete/edit race
            layriden = core.getView(forkiden).layers[0].iden
            layr = core.nexsroot._nexskids.pop(layriden)

            with self.raises(s_exc.NoSuchIden):
                await core.nodes('[ it:dev:str=foo ]', opts={'view': forkiden})

            core.nexsroot._nexskids[layriden] = layr

    async def test_nexus_iter(self):
        async with self.getTestCell(conf={'nexslog:en': True}) as cell:
            await cell.sync()

            # Force nexus events to be added while constructing a Window
            orig = s_nexus.NexsRoot.getMirrorWindow

            @contextlib.asynccontextmanager
            async def slowwindow(self):
                await cell.sync()
                async with orig(self) as wind:
                    await cell.sync()
                    yield wind

            items = []
            with mock.patch('synapse.lib.nexus.NexsRoot.getMirrorWindow', slowwindow):
                async with cell.getLocalProxy() as prox:
                    async for indx, item in prox.getNexusChanges(0):
                        items.append(indx)
                        if indx == 2:
                            await cell.sync()
                        elif indx == 3:
                            break

            # We didn't miss or duplicate items added during window construction
            self.eq([0, 1, 2, 3], items)

            nexsindx = cell.nexsroot.nexslog.index()

            async with cell.getLocalProxy() as prox:
                async def listen():
                    async for item in prox.getNexusChanges(nexsindx, wait=True):
                        break
                    return item

                task = cell.schedCoro(listen())
                await cell.sync()

                offs, item = await asyncio.wait_for(task, timeout=5)
                self.eq(offs, nexsindx)
                self.eq(item[1], 'sync')

    async def test_nexus_mirror_nowait(self):

        with self.getTestDir() as dirn:
            path00 = s_common.genpath(dirn, 'core00')
            path01 = s_common.genpath(dirn, 'core01')
            conf00 = {'nexslog:en': True}

            async with self.getTestCore(dirn=path00, conf=conf00) as core00:
                pass

            s_backup.backup(path00, path01)

            async with self.getTestCore(dirn=path00, conf=conf00) as core00:
                conf01 = {'nexslog:en': True, 'mirror': core00.getLocalUrl()}
                async with self.getTestCore(dirn=path01, conf=conf01) as core01:

                    evnt1 = asyncio.Event()
                    evnt2 = asyncio.Event()
                    orig = core00.auth.reqUser

                    async def slowReq(iden):
                        await evnt1.wait()
                        valu = await orig(iden)
                        evnt2.set()
                        return valu

                    await core01.sync()
                    self.true(core01.nexsroot.issuewait)

                    with mock.patch.object(core00.auth, 'reqUser', slowReq):

                        self.eq(len(core00.views), len(core01.views))

                        deflayr = (await core00.getLayerDef()).get('iden')

                        vdef = {'layers': (deflayr,), 'name': 'nextview'}
                        await core01.addView(vdef)

                        # We can finish handling the view add event on the mirror before the leader
                        self.eq(len(core00.views) + 1, len(core01.views))

                        evnt1.set()
                        await evnt2.wait()

                        self.eq(len(core00.views), len(core01.views))

                        await core00.getCellNexsRoot().addWriteHold('readonly')
                        strt = await core01.nexsroot.index()

                        # We still get exceptions that occur before adding the nexus event
                        with self.raises(s_exc.IsReadOnly) as cm:
                            await core01.addView(vdef)

                        self.eq(strt, await core01.nexsroot.index())

                        await core00.getCellNexsRoot().delWriteHold('readonly')

                core00.features.pop('issuewait')
                async with self.getTestCore(dirn=path01, conf=conf01) as core01:

                    await core01.sync()
                    self.false(core01.nexsroot.issuewait)

    async def test_nexus_mirror_of_mirror_nowait(self):

        with self.getTestDir() as dirn:
            path00 = s_common.genpath(dirn, 'core00')
            path01 = s_common.genpath(dirn, 'core01')
            path02 = s_common.genpath(dirn, 'core02')
            conf00 = {'nexslog:en': True}

            async with self.getTestCore(dirn=path00, conf=conf00) as core00:
                pass

            s_backup.backup(path00, path01)
            s_backup.backup(path00, path02)

            async with self.getTestCore(dirn=path00, conf=conf00) as core00:

                conf01 = {'nexslog:en': True, 'mirror': core00.getLocalUrl()}
                async with self.getTestCore(dirn=path01, conf=conf01) as core01:

                    conf02 = {'nexslog:en': True, 'mirror': core01.getLocalUrl()}
                    async with self.getTestCore(dirn=path02, conf=conf02) as core02:

                        await core02.sync()
                        self.true(core01.nexsroot.issuewait)
                        self.true(core02.nexsroot.issuewait)

                        evnt1 = asyncio.Event()
                        evnt2 = asyncio.Event()
                        evnt3 = asyncio.Event()
                        orig0 = core00.auth.reqUser
                        orig1 = core01.auth.reqUser

                        async def slowReq0(iden):
                            await evnt1.wait()
                            valu = await orig0(iden)
                            evnt2.set()
                            return valu

                        async def slowReq1(iden):
                            await evnt1.wait()
                            valu = await orig1(iden)
                            evnt3.set()
                            return valu

                        with (mock.patch.object(core00.auth, 'reqUser', slowReq0),
                              mock.patch.object(core01.auth, 'reqUser', slowReq1)):

                            self.eq(len(core00.views), len(core01.views))
                            self.eq(len(core00.views), len(core02.views))

                            deflayr = (await core00.getLayerDef()).get('iden')

                            vdef = {'layers': (deflayr,), 'name': 'nextview'}
                            await core02.addView(vdef)

                            # We can finish handling the view add event on the mirror leaf mirror first
                            self.eq(len(core00.views) + 1, len(core02.views))
                            self.eq(len(core01.views) + 1, len(core02.views))

                            evnt1.set()
                            await evnt2.wait()
                            await evnt3.wait()

                            self.eq(len(core00.views), len(core01.views))
                            self.eq(len(core00.views), len(core02.views))

                            await core00.getCellNexsRoot().addWriteHold('readonly')
                            strt = await core02.nexsroot.index()

                            # We still get exceptions that occur before adding the nexus event
                            with self.raises(s_exc.IsReadOnly) as cm:
                                await core02.addView(vdef)

                            self.eq(strt, await core02.nexsroot.index())

                            await core00.getCellNexsRoot().delWriteHold('readonly')

                core00.features.pop('issuewait')
                async with self.getTestCore(dirn=path01, conf=conf01) as core01:
                    async with self.getTestCore(dirn=path02, conf=conf02) as core02:
                        await core02.sync()
                        self.false(core01.nexsroot.issuewait)
                        self.true(core02.nexsroot.issuewait)

    async def test_nexus_mirror_connect_timeout(self):

        with self.getTestDir() as dirn:

            path00 = s_common.genpath(dirn, 'core00')
            path01 = s_common.genpath(dirn, 'core01')

            async with self.getTestAha() as aha:

                conf00 = {'aha:provision': await aha.addAhaSvcProv('00.cortex')}

                async with self.getTestCore(dirn=path00, conf=conf00) as core00:

                    provinfo = {'mirror': '00.cortex'}
                    conf01 = {'aha:provision': await aha.addAhaSvcProv('01.cortex', provinfo=provinfo)}
                    async with self.getTestCore(dirn=path01, conf=conf01) as core01:
                        pass

                with mock.patch('synapse.lib.nexus.FOLLOWER_CONNECT_WAIT_S', 0.05), \
                     mock.patch('synapse.lib.nexus.FOLLOWER_WRITE_WAIT_S', 0.05):

                    async with self.getTestCore(dirn=path01, conf=conf01) as core01:

                        # We weren't able to connect to the leader within the timeout so we're readonly
                        self.true(core01.nexsroot.readonly)
                        self.isin(s_nexus.mirrordisconnect, core01.nexsroot.writeholds)

                        evnt1 = asyncio.Event()
                        orig = s_nexus.NexsRoot._eat
                        async def hookEat(self, item, indx=None):
                            evnt1.set()
                            return await orig(self, item, indx=indx)

                        with mock.patch('synapse.lib.nexus.NexsRoot._eat', hookEat):
                            async with self.getTestCore(dirn=path00, conf=conf00) as core00:

                                await s_common.wait_for(core01.nexsroot.miruplink.wait(), 1)

                                self.false(core01.nexsroot.readonly)
                                self.len(0, core01.nexsroot.writeholds)

                                self.len(1, core00.views)
                                self.len(1, core01.views)

                                # Clear mirrors on the leader to ensure we don't receive a response
                                await core01.sync()
                                core00.nexsroot._linkmirrors.clear()

                                deflayr = (await core00.getLayerDef()).get('iden')
                                vdef = {'layers': (deflayr,), 'name': 'nextview'}
                                evnt1.clear()
                                coro = core01.schedCoro(core01.addView(vdef))

                                await evnt1.wait()

                        # Our task should be cancelled by the reconnect timeout
                        with self.raises(s_exc.LinkErr) as cm:
                            await coro

                        self.true(cm.exception.get('mesg').startswith('Unable to connect to leader'))
                        self.true(core01.nexsroot.readonly)
                        self.isin(s_nexus.mirrordisconnect, core01.nexsroot.writeholds)

                        # We didn't get the event from the leader yet
                        self.len(1, core01.views)

                        async with self.getTestCore(dirn=path00, conf=conf00) as core00:

                            await s_common.wait_for(core01.nexsroot.miruplink.wait(), 1)

                            self.false(core01.nexsroot.readonly)
                            self.len(0, core01.nexsroot.writeholds)

                            await core01.sync()

                            # Now we're sync'ed and caught back up
                            self.len(2, core00.views)
                            self.len(2, core01.views)

                            # After promotion we should not have any stray connect timeouts
                            await core01.promote(graceful=True)
                            await s_common.wait_for(core00.nexsroot.miruplink.wait(), 6)

                            self.false(core00.nexsroot.readonly)
                            self.false(core01.nexsroot.readonly)
                            self.len(0, core00.nexsroot.writeholds)
                            self.len(0, core01.nexsroot.writeholds)
